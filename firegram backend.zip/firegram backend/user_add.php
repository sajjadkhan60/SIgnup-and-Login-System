<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header("Access-Control-Allow-Methods: POST");
header("Allow: GET, POST, OPTIONS, PUT, DELETE");
header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method, Access-Control-Allow-Origin");
include("connection.php");

$input = file_get_contents('php://input');
$data = json_decode($input, true);
$name = $data["fname"];
$email = $data["email"];
$password = $data["password"];


$sql = "SELECT * FROM users WHERE email= '$email'";

$query = mysqli_query($con, $sql);

$num_rows = mysqli_num_rows($query);
if ($num_rows == 0) {
    $sql = "INSERT INTO users VALUES(NULL,'$name','$email','$password')";
    $query = mysqli_query($con, $sql);
    if ($query) {
        echo json_encode(array('insert' => 'success'));
    } else {
        echo json_encode(array('insert' => 'failed'));
    }
} else {
    echo json_encode(array('insert' => 'exists'));
}
?>