<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header("Access-Control-Allow-Methods: POST");
header("Allow: GET, POST, OPTIONS, PUT, DELETE");
header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method, Access-Control-Allow-Origin");
include("connection.php");

    $input = file_get_contents('php://input');
    $data = json_decode($input, true);
    $description = $_POST["description"];
    $userid = $_POST['userId'];
    $image_name = $_FILES['postImage']['name'];
    $image_tmp_name = $_FILES['postImage']['tmp_name'];


    move_uploaded_file($image_tmp_name, "post_images/$image_name");
    $img_url = "http://localhost/firegram/post_images/$image_name";
    $date = date("j F Y");
    $sql = "INSERT INTO posts VALUES(NULL,'$userid','$img_url','$description', '$date')";
    $query = mysqli_query($con, $sql);
    if ($query) {
        $sql2 = "SELECT * FROM posts WHERE user_id = '$userid' ORDER BY post_id DESC LIMIT 1";
        $query2 = mysqli_query($con, $sql2);
        $row = mysqli_fetch_array($query2);
        $postid = $row['post_id'];
        
        echo json_encode(array('insert' => 'success', 'imgUrl' => $img_url, 'date' => $date, 'postid' => $postid));
    } else {
        echo json_encode(array('insert' => 'failed'));
    }
?>