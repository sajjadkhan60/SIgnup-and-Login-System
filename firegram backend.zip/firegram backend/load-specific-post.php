<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header("Access-Control-Allow-Methods: POST");
header("Allow: GET, POST, OPTIONS, PUT, DELETE");
header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method, Access-Control-Allow-Origin");
include("connection.php");

$input = file_get_contents('php://input');
$data = json_decode($input, true);
$post_id = $_GET["post_id"];

$sql = "SELECT * FROM posts WHERE post_id = '$post_id'";
$query = mysqli_query($con, $sql);
$number = mysqli_num_rows($query);

$post = [];

if($number == 0){
    echo json_encode(array('number' => 0, 'post' => $post));
}else{
    $post = mysqli_fetch_array($query);
    
    $user_id = $post['user_id'];
    $sql2 = "SELECT * FROM users WHERE id = '$user_id'";
    $query2 = mysqli_query($con, $sql2);
    $data = mysqli_fetch_array($query2);
    $name = $data['name'];

    echo json_encode(array('number' => 1, 'post' => $post, 'username' => $name));
}




?>