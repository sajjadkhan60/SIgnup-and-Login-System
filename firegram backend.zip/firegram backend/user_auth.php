<?php
session_start();
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header("Access-Control-Allow-Methods: POST");
header("Allow: GET, POST, OPTIONS, PUT, DELETE");
header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method, Access-Control-Allow-Origin");
include("connection.php");

$input = file_get_contents('php://input');
$data = json_decode($input, true);
$email = $data["email"];
$password = $data["password"];


$sql = "SELECT * FROM users WHERE email= '$email' AND password = '$password'";

$query = mysqli_query($con, $sql);

$num_rows = mysqli_num_rows($query);
    if ($num_rows > 0) {
        $_SESSION['email'] = $email;
        echo json_encode(array('authentications' => 'login_success'));
    } else {
        echo json_encode(array('authentications' => 'login_failed'));
    }
?>