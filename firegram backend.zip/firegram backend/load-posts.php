<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header("Access-Control-Allow-Methods: POST");
header("Allow: GET, POST, OPTIONS, PUT, DELETE");
header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method, Access-Control-Allow-Origin");
include("connection.php");

$input = file_get_contents('php://input');
$data = json_decode($input, true);
$email = $_GET["email"];

$sql = "SELECT * FROM users WHERE email = '$email'";
$query = mysqli_query($con, $sql);

$data = mysqli_fetch_array($query);
$name = $data['name'];
$user_id = $data['id'];


$sql2 = "SELECT * FROM posts WHERE user_id = '$user_id' ORDER BY post_id DESC";
$query2 = mysqli_query($con, $sql2);
$number = mysqli_num_rows($query2);
$posts = [];
if($number == 0){
    echo json_encode(array('username' => $name, 'userid' => $user_id, 'posts' => $posts));
}else{
    while($row = mysqli_fetch_assoc($query2)){
        $posts[] = $row;
    }
    echo json_encode(array('username' => $name, 'userid' => $user_id, 'posts' => $posts));
}




?>