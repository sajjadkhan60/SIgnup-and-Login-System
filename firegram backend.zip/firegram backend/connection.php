<?php
$server = "localhost";
$user = "root";
$pass = "";
$database = "test";

$con = mysqli_connect($server, $user, $pass, $database);